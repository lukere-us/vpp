<?php

session_start();
//define('base_url', ' http://localhost/simulater/');
//define('base_url', ' http://vpp.biotechnocrat.com');
define('base_url', ' http://localhost:8080/vpp/');

//DB 
define('host', 'localhost');
define('user', 'root');
define('pwd', '');
define('db', 'microsq0_vpp');

//Alpha

//define('host', 'localhost');
//define('user', 'microsq0_preview');
//define('pwd', '4enzKd66xnqh');
//define('db', 'microsq0_vpp');

//Live
//define('host', 'localhost');
//define('user', 'qzjfjhmy_admin');
//define('pwd', '9{0~jK}[MaUt');
//define('db', 'microsq0_vpp');

?>